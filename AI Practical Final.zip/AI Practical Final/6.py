# any real time application using AI

from textblob import TextBlob
def fun(txt):
    b=TextBlob(txt)
    s=b.sentiment.polarity
    
    if s>0:
        print("positive")
    elif s<0:
        print("Negative")
    else:
        print("Neutral")
        
fun("She is a girl")