#4 REAL LIFE APPLICATION IN AI LIBRARIES PYTHON
#Application: Sentiment Analysis of Customer Reviews
import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, classification_report
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
import re

# Download NLTK data files
nltk.download('punkt')
nltk.download('stopwords')

class SentimentAnalysis:
    def __init__(self, dataset_path):
        self.dataset_path = dataset_path
        self.model = None
        self.vectorizer = None

    def preprocess(self, text):
        """Clean and preprocess text data."""
        text = re.sub(r'[^\w\s]', '', text)  # Remove punctuation
        text = text.lower()  # Convert to lowercase
        words = word_tokenize(text)  # Tokenize
        words = [word for word in words if word not in stopwords.words('english')]  # Remove stopwords
        return ' '.join(words)

    def load_and_prepare_data(self):
        """Load and prepare the dataset."""
        # Load dataset
        data = pd.read_csv(self.dataset_path)

        # Preprocess text
        data['review'] = data['review'].apply(self.preprocess)

        # Convert labels to binary (positive = 1, negative = 0)
        data['sentiment'] = data['sentiment'].map({'positive': 1, 'negative': 0})

        # Split data into features and labels
        X = data['review']
        y = data['sentiment']

        return X, y

    def train_model(self, X, y):
        """Train the sentiment analysis model."""
        # Convert text data to feature vectors
        self.vectorizer = CountVectorizer(max_features=1000)
        X_vectorized = self.vectorizer.fit_transform(X)

        # Split data into training and testing sets
        X_train, X_test, y_train, y_test = train_test_split(
            X_vectorized, y, test_size=0.2, random_state=42
        )

        # Train a Naive Bayes classifier
        self.model = MultinomialNB()
        self.model.fit(X_train, y_train)

        # Evaluate the model
        y_pred = self.model.predict(X_test)
        print("Accuracy:", accuracy_score(y_test, y_pred))
        print("Classification Report:\n", classification_report(y_test, y_pred))

    def predict(self, review):
        """Predict sentiment for a given review."""
        if not self.model or not self.vectorizer:
            raise Exception("Model not trained. Call train_model() first.")

        # Preprocess and vectorize the input review
        review = self.preprocess(review)
        review_vectorized = self.vectorizer.transform([review])

        # Predict sentiment
        prediction = self.model.predict(review_vectorized)
        return "Positive" if prediction[0] == 1 else "Negative"


# Example Usage
if __name__ == "__main__":
    # Create a dataset file with sample reviews for testing
    sample_data = {
        'review': [
            "The product is great and works perfectly!",
            "Terrible experience, I want a refund.",
            "Customer service was helpful and quick.",
            "The item broke after two uses. Awful!",
            "Absolutely love this! Highly recommend.",
        ],
        'sentiment': ['positive', 'negative', 'positive', 'negative', 'positive']
    }
    dataset_path = 'customer_reviews.csv'
    pd.DataFrame(sample_data).to_csv(dataset_path, index=False)

    # Initialize and train sentiment analysis model
    sentiment_analyzer = SentimentAnalysis(dataset_path)
    X, y = sentiment_analyzer.load_and_prepare_data()
    sentiment_analyzer.train_model(X, y)

    # Test the model with a custom review
    test_review = "The delivery was quick but the product quality is poor."
    print(f"Review: {test_review}")
    print("Predicted Sentiment:", sentiment_analyzer.predict(test_review))
