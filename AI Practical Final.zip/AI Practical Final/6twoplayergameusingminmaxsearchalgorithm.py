#6 two player game using min max search algorithm
import math

class TicTacToe:
    def __init__(self):
        self.board = [' ' for _ in range(9)]  # 3x3 board
        self.current_winner = None  # Track the winner

    def print_board(self):
        """Prints the current board state."""
        for row in [self.board[i * 3:(i + 1) * 3] for i in range(3)]:
            print('| ' + ' | '.join(row) + ' |')

    def available_moves(self):
        """Returns a list of available positions."""
        return [i for i, spot in enumerate(self.board) if spot == ' ']

    def empty_squares(self):
        """Checks if there are empty squares."""
        return ' ' in self.board

    def num_empty_squares(self):
        """Returns the number of empty squares."""
        return self.board.count(' ')

    def make_move(self, square, letter):
        """
        Makes a move on the board.
        Args:
        - square: Position to place the move.
        - letter: 'X' or 'O'.
        """
        if self.board[square] == ' ':
            self.board[square] = letter
            if self.winner(square, letter):
                self.current_winner = letter
            return True
        return False

    def winner(self, square, letter):
        """
        Checks if there is a winner.
        Args:
        - square: Last move position.
        - letter: 'X' or 'O'.
        """
        # Check row
        row_ind = square // 3
        row = self.board[row_ind * 3:(row_ind + 1) * 3]
        if all([spot == letter for spot in row]):
            return True

        # Check column
        col_ind = square % 3
        column = [self.board[col_ind + i * 3] for i in range(3)]
        if all([spot == letter for spot in column]):
            return True

        # Check diagonals
        if square % 2 == 0:  # Only possible for even-indexed squares
            diagonal1 = [self.board[i] for i in [0, 4, 8]]  # Top-left to bottom-right
            if all([spot == letter for spot in diagonal1]):
                return True
            diagonal2 = [self.board[i] for i in [2, 4, 6]]  # Top-right to bottom-left
            if all([spot == letter for spot in diagonal2]):
                return True

        return False

def minimax(state, player, alpha, beta, depth=0):
    """
    Minimax algorithm with alpha-beta pruning.
    Args:
    - state: Current board state.
    - player: 'X' (maximizer) or 'O' (minimizer).
    - alpha: Best value for maximizer.
    - beta: Best value for minimizer.
    - depth: Current depth of recursion.
    """
    max_player = 'X'  # Human
    other_player = 'O' if player == 'X' else 'X'

    # Check for a terminal state
    if state.current_winner == other_player:
        return {'position': None, 'score': 1 * (state.num_empty_squares() + 1) if other_player == max_player else -1 * (state.num_empty_squares() + 1)}

    elif not state.empty_squares():  # No empty squares
        return {'position': None, 'score': 0}

    if player == max_player:  # Maximizing player
        best = {'position': None, 'score': -math.inf}
    else:  # Minimizing player
        best = {'position': None, 'score': math.inf}

    for possible_move in state.available_moves():
        # Make the move
        state.make_move(possible_move, player)
        sim_score = minimax(state, other_player, alpha, beta, depth + 1)  # Simulate the game

        # Undo the move
        state.board[possible_move] = ' '
        state.current_winner = None
        sim_score['position'] = possible_move

        # Update the best move
        if player == max_player:
            if sim_score['score'] > best['score']:
                best = sim_score
            alpha = max(alpha, best['score'])
        else:
            if sim_score['score'] < best['score']:
                best = sim_score
            beta = min(beta, best['score'])

        if beta <= alpha:
            break

    return best

def play():
    game = TicTacToe()
    print("Welcome to Tic Tac Toe!")
    game.print_board()

    while game.empty_squares():
        # Human move
        if game.num_empty_squares() % 2 == 0:
            while True:  # Loop until a valid move is made
                try:
                    square = int(input("Enter your move (0-8): "))
                    if square < 0 or square > 8:
                        print("Please enter a valid number between 0 and 8.")
                        continue
                    if game.board[square] != ' ':
                        print("This position is already occupied. Try again.")
                        continue
                    if game.make_move(square, 'X'):
                        break
                except ValueError:
                    print("Invalid input. Please enter a number between 0 and 8.")
        else:  # AI move
            print("AI is thinking...")
            move = minimax(game, 'O', -math.inf, math.inf)
            game.make_move(move['position'], 'O')

        game.print_board()

        if game.current_winner:
            if game.current_winner == 'X':
                print("You win!")
            else:
                print("AI wins!")
            return

    print("It's a tie!")

if __name__ == "__main__":
    play()
