#5 expert system in python
class ExpertSystem:
    def __init__(self):
        self.knowledge_base = {
            "common_cold": {
                "symptoms": ["cough", "sneezing", "sore throat", "runny nose", "congestion"],
                "description": "You may have a common cold. It is usually caused by a viral infection.",
                "advice": "Rest, drink fluids, and consider over-the-counter cold medications."
            },
            "flu": {
                "symptoms": ["fever", "chills", "body aches", "fatigue", "headache"],
                "description": "You may have the flu. It is caused by the influenza virus.",
                "advice": "Rest, stay hydrated, and consider consulting a doctor if symptoms persist."
            },
            "allergy": {
                "symptoms": ["sneezing", "runny nose", "itchy eyes", "congestion"],
                "description": "You may have allergies. Allergies are caused by a reaction to allergens like pollen or dust.",
                "advice": "Avoid allergens, consider antihistamines, and consult an allergist if necessary."
            },
            "migraine": {
                "symptoms": ["headache", "nausea", "sensitivity to light", "sensitivity to sound"],
                "description": "You may have a migraine. It is a neurological condition that can cause severe headaches.",
                "advice": "Rest in a dark, quiet room, and consider pain relievers or migraine-specific medication."
            }
        }

    def diagnose(self, symptoms):
        """Diagnoses the condition based on the symptoms provided."""
        for condition, details in self.knowledge_base.items():
            if any(symptom in symptoms for symptom in details["symptoms"]):  # Check if any symptom matches
                return {
                    "condition": condition,
                    "description": details["description"],
                    "advice": details["advice"]
                }
        return {
            "condition": "unknown",
            "description": "Your symptoms do not match any condition in our database.",
            "advice": "Consult a healthcare professional for further assistance."
        }


# Example Usage
if __name__ == "__main__":
    print("Welcome to the Health Expert System!")
    print("Please enter your symptoms separated by commas.")
    user_input = input("Symptoms: ").strip().lower()
    user_symptoms = [symptom.strip() for symptom in user_input.split(",")]

    expert_system = ExpertSystem()
    diagnosis = expert_system.diagnose(user_symptoms)

    print("\nDiagnosis:")
    print(f"Condition: {diagnosis['condition']}")
    print(f"Description: {diagnosis['description']}")
    print(f"Advice: {diagnosis['advice']}")
