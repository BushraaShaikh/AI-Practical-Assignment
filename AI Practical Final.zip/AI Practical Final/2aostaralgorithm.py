#2 AOSTAR ALGORITHM
class AOStar:
    def __init__(self, graph, heuristic):
        """
        Initialize the AO* algorithm.
        :param graph: A dictionary where each node maps to its children (AND/OR arcs).
        :param heuristic: A dictionary of heuristic values for each node.
        """
        self.graph = graph
        self.heuristic = heuristic
        self.solution_graph = {}

    def explore_and_backtrack(self, node):
        """
        Explore the graph recursively and perform backtracking to update costs.
        :param node: The current node being processed.
        :return: The updated cost for the current node.
        """
        # If the node is a terminal node, return its heuristic cost
        if node not in self.graph or not self.graph[node]:
            self.solution_graph[node] = None
            return self.heuristic[node]

        min_cost = float('inf')
        best_option = None

        # Explore all arcs (AND/OR) for the current node
        for children in self.graph[node]:
            cost = 0
            for child in children:
                cost += self.explore_and_backtrack(child)  # Recursive call

            # Choose the arc with the minimum cost
            if cost < min_cost:
                min_cost = cost
                best_option = children

        # Update the solution graph and heuristic cost
        self.solution_graph[node] = best_option
        self.heuristic[node] = min_cost

        return min_cost

    def find_solution(self, start_node):
        """
        Find the solution starting from the root node.
        :param start_node: The root node of the graph.
        :return: The final solution graph.
        """
        self.explore_and_backtrack(start_node)
        return self.solution_graph


# Example Usage
if __name__ == "__main__":
    # Define an AND-OR graph as a dictionary
    # Each node maps to a list of arcs, where each arc is a list of child nodes
    graph = {
        'A': [['B', 'C'], ['D']],
        'B': [['E'], ['F']],
        'C': [['G']],
        'D': [['H']],
        'E': [],
        'F': [],
        'G': [],
        'H': []
    }

    # Define heuristic values for each node
    heuristic = {
        'A': 1, 'B': 1, 'C': 2, 'D': 2,
        'E': 3, 'F': 4, 'G': 5, 'H': 6
    }

    # Run AO* algorithm
    aostar = AOStar(graph, heuristic)
    solution = aostar.find_solution('A')

    print("Solution Graph:", solution)
