from collections import deque

def bfs(graph):
    vis=[False]*10
    q=deque()
    q.append(0)
    while q:
        curr=q.popleft()
        if not vis[curr]:
            print(curr)
            vis[curr]=True
            for n in graph[curr]:
                if not vis[n]:
                    q.append(n)
       
       
graph = {
    0: [1, 2],
    1: [0, 3, 4],
    2: [0, 5],
    3: [1],
    4: [1],
    5: [2]
}

bfs(graph)