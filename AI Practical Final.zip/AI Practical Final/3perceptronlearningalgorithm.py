#3 PERCEPTRON LEARNING ALGORITHM
import numpy as np

class Perceptron:
    def __init__(self, learning_rate=0.01, epochs=100):
        self.learning_rate = learning_rate
        self.epochs = epochs
        self.weights = None
        self.bias = None

    def activation(self, x):
        """Activation function: Step function"""
        return 1 if x >= 0 else 0

    def fit(self, X, y):
        """
        Train the Perceptron algorithm.
        Args:
        - X: Input features (numpy array of shape [n_samples, n_features]).
        - y: Labels (numpy array of shape [n_samples]).
        """
        n_samples, n_features = X.shape

        # Initialize weights and bias
        self.weights = np.zeros(n_features)
        self.bias = 0

        # Training loop
        for epoch in range(self.epochs):
            for idx, x_i in enumerate(X):
                # Linear combination of weights and input features
                linear_output = np.dot(x_i, self.weights) + self.bias
                y_pred = self.activation(linear_output)

                # Update weights and bias if prediction is incorrect
                error = y[idx] - y_pred
                self.weights += self.learning_rate * error * x_i
                self.bias += self.learning_rate * error

    def predict(self, X):
        """
        Make predictions using the trained model.
        Args:
        - X: Input features (numpy array of shape [n_samples, n_features]).
        Returns:
        - Predictions (numpy array of shape [n_samples]).
        """
        linear_output = np.dot(X, self.weights) + self.bias
        return np.array([self.activation(x) for x in linear_output])


# Example Usage
if __name__ == "__main__":
    # AND gate data
    X = np.array([
        [0, 0],
        [0, 1],
        [1, 0],
        [1, 1]
    ])
    y = np.array([0, 0, 0, 1])  # AND gate output

    # Initialize and train the perceptron
    perceptron = Perceptron(learning_rate=0.1, epochs=10)
    perceptron.fit(X, y)

    # Test the perceptron
    predictions = perceptron.predict(X)
    print("Predictions:", predictions)
    print("Weights:", perceptron.weights)
    print("Bias:", perceptron.bias)
