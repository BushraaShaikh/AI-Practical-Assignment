#7 fuzzy set for shape matching of hand written character
import numpy as np
import skfuzzy as fuzz
import matplotlib.pyplot as plt

class HandwrittenCharacterMatcher:
    def __init__(self):
        self.attributes = {
            "curvature": np.arange(0, 101, 1),  # Curvature values (0 to 100)
            "angle": np.arange(0, 181, 1),  # Angle values (0° to 180°)
            "stroke_length": np.arange(0, 51, 1),  # Stroke length (0 to 50)
        }

        # Define fuzzy membership functions for each attribute
        self.curvature_membership = {
            "low": fuzz.trimf(self.attributes["curvature"], [0, 0, 50]),
            "medium": fuzz.trimf(self.attributes["curvature"], [25, 50, 75]),
            "high": fuzz.trimf(self.attributes["curvature"], [50, 100, 100]),
        }

        self.angle_membership = {
            "small": fuzz.trimf(self.attributes["angle"], [0, 0, 90]),
            "medium": fuzz.trimf(self.attributes["angle"], [45, 90, 135]),
            "large": fuzz.trimf(self.attributes["angle"], [90, 180, 180]),
        }

        self.stroke_length_membership = {
            "short": fuzz.trimf(self.attributes["stroke_length"], [0, 0, 25]),
            "medium": fuzz.trimf(self.attributes["stroke_length"], [10, 25, 40]),
            "long": fuzz.trimf(self.attributes["stroke_length"], [25, 50, 50]),
        }

    def visualize_memberships(self):
        """Visualizes the fuzzy membership functions."""
        fig, axes = plt.subplots(1, 3, figsize=(15, 5))

        # Curvature
        axes[0].plot(
            self.attributes["curvature"],
            self.curvature_membership["low"],
            label="Low",
            color="blue"
        )
        axes[0].plot(
            self.attributes["curvature"],
            self.curvature_membership["medium"],
            label="Medium",
            color="green"
        )
        axes[0].plot(
            self.attributes["curvature"],
            self.curvature_membership["high"],
            label="High",
            color="red"
        )
        axes[0].set_title("Curvature")
        axes[0].legend()

        # Angle
        axes[1].plot(
            self.attributes["angle"],
            self.angle_membership["small"],
            label="Small",
            color="blue"
        )
        axes[1].plot(
            self.attributes["angle"],
            self.angle_membership["medium"],
            label="Medium",
            color="green"
        )
        axes[1].plot(
            self.attributes["angle"],
            self.angle_membership["large"],
            label="Large",
            color="red"
        )
        axes[1].set_title("Angle")
        axes[1].legend()

        # Stroke Length
        axes[2].plot(
            self.attributes["stroke_length"],
            self.stroke_length_membership["short"],
            label="Short",
            color="blue"
        )
        axes[2].plot(
            self.attributes["stroke_length"],
            self.stroke_length_membership["medium"],
            label="Medium",
            color="green"
        )
        axes[2].plot(
            self.attributes["stroke_length"],
            self.stroke_length_membership["long"],
            label="Long",
            color="red"
        )
        axes[2].set_title("Stroke Length")
        axes[2].legend()

        plt.tight_layout()
        plt.show()

    def calculate_membership(self, curvature, angle, stroke_length):
        """Calculates membership values for given inputs."""
        curvature_membership = {
            k: fuzz.interp_membership(self.attributes["curvature"], v, curvature)
            for k, v in self.curvature_membership.items()
        }

        angle_membership = {
            k: fuzz.interp_membership(self.attributes["angle"], v, angle)
            for k, v in self.angle_membership.items()
        }

        stroke_length_membership = {
            k: fuzz.interp_membership(self.attributes["stroke_length"], v, stroke_length)
            for k, v in self.stroke_length_membership.items()
        }

        return {
            "curvature": curvature_membership,
            "angle": angle_membership,
            "stroke_length": stroke_length_membership,
        }


# Example Usage
if __name__ == "__main__":
    matcher = HandwrittenCharacterMatcher()
    matcher.visualize_memberships()

    # Example input features for a handwritten character
    input_curvature = 60
    input_angle = 120
    input_stroke_length = 30

    memberships = matcher.calculate_membership(
        input_curvature, input_angle, input_stroke_length
    )

    print("Membership values for curvature:", memberships["curvature"])
    print("Membership values for angle:", memberships["angle"])
    print("Membership values for stroke length:", memberships["stroke_length"])
