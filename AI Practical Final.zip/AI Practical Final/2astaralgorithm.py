#2 implementation of A* Algorithm

def A_star(start_node,stop_node):
	open_set=set(start_node)
	close_set=set()
	g={}  #store distance from starting node
	parents={}  #contains an adjency map of all nodes
	g[start_node]=0
	parents[start_node]=start_node  #if start node is root node i.e. it has no parent node so start node is set to its own parent node
	while len(open_set)>0:
		n=None
		#node with lowest F(n) is found
		for v in open_set:
			if n==None or g[v]+heuristic(v)<g[n]+heuristic(n):
				n=v
		if n==stop_node or graph_nodes[n]==None:
			pass
		else:
			for (m,weight) in get_neighboures(n):
			#nodes m not in first and last set are added and n is set as its parent
				if m not in open_set and m not in close_set:
					open_set.add(m)
					parents[m]=n
					g[m]=g[n]+weight
				else:  
				#for each node m compare its distance from start to n node
					if g[m]>g[n]+weight:
						g[m]=g[n]+weight  #update value of g[m]
						parents[m]=n  #change parent of m to n
						if m in close_set:  #if m is present in close set remove and add to open set
							close_set.remove(m)
							open_set.add(m)
		if n==None:
			print("Path does not exist..!")
			return None
		if n==stop_node:
		#if current node is the stop node then we begin reconstructing the path from it to the start node
			path=[]
			while parents[n]!=n:
				path.append(n)
				n=parents[n]
			path.append(start_node)
			path.reverse()
			print("Path found:{}".format(path))
			return path
	#remove n from the open list and add into the close list because all its neighbours are inspected
		open_set.remove(n)
		close_set.add(n)
	print("Path does not exist")
	return None
	
#define function to return neighbours and its distance from the pass nodes
def get_neighboures(v):
	if v in graph_nodes:
		return graph_nodes[v]
	else:
		return None
		
def heuristic(n):
#consider heuristic distances given and its functions for all nodes
	h_dist={'A':11, 'B':6, 'C':19, 'D':1, 'E':7, 'G':0}
	return h_dist[n]
	
graph_nodes={
	'A':[('B',2),('E',5)], 
	'B':[('C',1),('G',9)], 
	'C':'None', 
	'D':[('G',1)], 
	'E':[('D',6)]
	}

A_star('A','G')