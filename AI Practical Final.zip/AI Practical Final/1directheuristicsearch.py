#1 Direct Heuristic Search Techniques
import heapq

class HeuristicSearch:
    def __init__(self, grid, start, goal):
        self.grid = grid
        self.start = start
        self.goal = goal
        self.rows = len(grid)
        self.cols = len(grid[0])

    def heuristic(self, current):
        """Manhattan distance heuristic."""
        return abs(current[0] - self.goal[0]) + abs(current[1] - self.goal[1])

    def is_valid(self, x, y):
        """Check if a cell is valid and within grid bounds."""
        return 0 <= x < self.rows and 0 <= y < self.cols and self.grid[x][y] == 0

    def best_first_search(self):
        """Implements Best-First Search."""
        open_set = [(self.heuristic(self.start), self.start)]
        visited = set()

        while open_set:
            _, current = heapq.heappop(open_set)
            if current in visited:
                continue
            visited.add(current)

            if current == self.goal:
                return True

            for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                neighbor = (current[0] + dx, current[1] + dy)
                if neighbor not in visited and self.is_valid(*neighbor):
                    heapq.heappush(open_set, (self.heuristic(neighbor), neighbor))

        return False

    def greedy_search(self):
        """Implements Greedy Search."""
        open_set = [(self.heuristic(self.start), self.start)]
        visited = set()

        while open_set:
            _, current = heapq.heappop(open_set)
            if current in visited:
                continue
            visited.add(current)

            if current == self.goal:
                return True

            for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                neighbor = (current[0] + dx, current[1] + dy)
                if neighbor not in visited and self.is_valid(*neighbor):
                    heapq.heappush(open_set, (self.heuristic(neighbor), neighbor))

        return False

    def hill_climbing(self):
        """Implements Hill-Climbing."""
        current = self.start

        while current != self.goal:
            neighbors = []
            for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                neighbor = (current[0] + dx, current[1] + dy)
                if self.is_valid(*neighbor):
                    neighbors.append((self.heuristic(neighbor), neighbor))

            if not neighbors:
                return False  # No path found

            # Choose the neighbor with the smallest heuristic
            next_move = min(neighbors, key=lambda x: x[0])[1]

            # If the heuristic doesn't improve, stop
            if self.heuristic(next_move) >= self.heuristic(current):
                return False

            current = next_move

        return True


# Example Usage
if __name__ == "__main__":
    grid = [
        [0, 0, 0, 1, 0],
        [0, 1, 0, 1, 0],
        [0, 1, 0, 0, 0],
        [0, 0, 0, 1, 0],
        [1, 1, 0, 0, 0]
    ]
    start = (0, 0)
    goal = (4, 4)

    search = HeuristicSearch(grid, start, goal)
    print("Best-First Search:", search.best_first_search())
    print("Greedy Search:", search.greedy_search())
    print("Hill-Climbing:", search.hill_climbing())
