# expert System
def es():
    print("Welcome/n Ans in yes or no")
    fever=input("Do u have fever").lower()
    cough=input("Do u have cough").lower()
    sore_throat=input("Do u have sour throat").lower()
    headache=input("Do u have headache").lower()
    
    if fever == "yes" and cough == "yes" and sore_throat == "yes":
        print("\nDiagnosis: You may have the flu. Please consult a doctor.")
    elif fever == "yes" and headache == "yes":
        print("\nDiagnosis: You may have a viral infection. Stay hydrated and rest.")
    elif cough == "yes" and sore_throat == "yes":
        print("\nDiagnosis: You may have a cold. Drink warm fluids and rest.")
    else:
        print("\nDiagnosis: Symptoms are unclear. Please consult a doctor for a proper diagnosis.")

es()
    