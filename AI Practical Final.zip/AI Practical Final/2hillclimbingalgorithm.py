#2 HILL CLIMBING ALGORITHM
import random

class HillClimbing:
    def __init__(self, objective_function, neighbors_function):
        """
        Initialize the Hill Climbing algorithm.
        :param objective_function: Function to evaluate the fitness of a solution.
        :param neighbors_function: Function to generate neighbors for a given solution.
        """
        self.objective_function = objective_function
        self.neighbors_function = neighbors_function

    def climb(self, start, max_iterations=1000):
        """
        Perform the Hill Climbing algorithm.
        :param start: The starting solution.
        :param max_iterations: Maximum number of iterations.
        :return: The best solution found and its objective value.
        """
        current_solution = start
        current_value = self.objective_function(current_solution)
        
        for _ in range(max_iterations):
            neighbors = self.neighbors_function(current_solution)
            if not neighbors:
                break  # No neighbors to explore
            
            next_solution = max(neighbors, key=self.objective_function)
            next_value = self.objective_function(next_solution)
            
            # Stop if no improvement
            if next_value <= current_value:
                break
            
            current_solution, current_value = next_solution, next_value

        return current_solution, current_value


# Example Usage
if __name__ == "__main__":
    # Example: Maximize the objective function f(x) = -x^2 + 5x + 10

    def objective_function(x):
        # The objective function to maximize
        return -x**2 + 5 * x + 10

    def neighbors_function(x):
        # Generate neighbors by moving +/- 1 step
        step = 1
        return [x - step, x + step]

    # Starting point
    start = random.randint(-10, 10)

    # Run the algorithm
    hill_climbing = HillClimbing(objective_function, neighbors_function)
    best_solution, best_value = hill_climbing.climb(start)

    print("Best Solution:", best_solution)
    print("Objective Value at Best Solution:", best_value)
